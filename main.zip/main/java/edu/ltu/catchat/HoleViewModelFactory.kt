package edu.ltu.catchat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

class HoleViewModelFactory(private val dao: HoleDao)
    : ViewModelProvider.Factory {
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(HoleViewModel::class.java)) {
            return HoleViewModel(dao) as T
        }
        throw IllegalArgumentException("Unknown ViewModel")
    }
}