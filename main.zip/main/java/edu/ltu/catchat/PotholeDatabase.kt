package edu.ltu.catchat

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Pothole::class], version = 1, exportSchema = false)
abstract class PotholeDatabase :RoomDatabase() {
    abstract val taskDao: HoleDao

    companion object {
        @Volatile
        private var INSTANCE: PotholeDatabase? = null
        fun getInstance(context: Context): PotholeDatabase {
            synchronized(this) {
                var instance = INSTANCE
                if (instance == null) {
                    instance = Room.databaseBuilder(
                        context.applicationContext,
                        PotholeDatabase::class.java,
                        "tasks_database"
                    ).build()
                    INSTANCE = instance
                }
                return instance
            }
        }
    }
}