package edu.ltu.catchat

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface HoleDao {
    @Insert
    suspend fun insert(pothole: Pothole)
    @Update
    suspend fun update(pothole: Pothole)
    @Delete
    suspend fun delete(pothole: Pothole)
    @Query("SELECT * FROM task_table WHERE potholeId = :key")
    fun get(key: Long): LiveData<Pothole>
    @Query("SELECT * FROM task_table ORDER BY potholeId DESC")
    fun getAll(): LiveData<List<Pothole>>
}