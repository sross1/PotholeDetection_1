package edu.ltu.catchat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class HoleViewModel(val dao: HoleDao) : ViewModel() {
    var newTaskName = ""
    val tasks = dao.getAll()

    fun addTask() {
        viewModelScope.launch {
            val task = Pothole()
            task.potholeNumber = newTaskName
            dao.insert(task)
        }
    }
}