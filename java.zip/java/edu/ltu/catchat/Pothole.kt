package edu.ltu.catchat

import android.media.MicrophoneInfo.Coordinate3F
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "task_table")
data class Pothole (
    @PrimaryKey(autoGenerate = true)
    var potholeId: Long = 0L,
    @ColumnInfo(name = "Pothole_Number")
    var potholeNumber: String = "",
    @ColumnInfo(name = "Location")
    var potholeCoordinates: String = ""
)